ol.proj.proj4.register(proj4);
//ol.proj.get("EPSG:3857").setExtent([-2568539.754046, 1692062.256477, 2039681.866228, 4357893.688420]);
var wms_layers = [];


        var lyr_GoogleHybrid_0 = new ol.layer.Tile({
            'title': 'Google Hybrid',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: '&nbsp;&middot; <a href="https://www.google.at/permissions/geoguidelines/attr-guide.html">Map data ©2015 Google</a>',
                url: 'https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}'
            })
        });
var format_populaion_region_1 = new ol.format.GeoJSON();
var features_populaion_region_1 = format_populaion_region_1.readFeatures(json_populaion_region_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_populaion_region_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_populaion_region_1.addFeatures(features_populaion_region_1);
var lyr_populaion_region_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_populaion_region_1, 
                style: style_populaion_region_1,
                popuplayertitle: 'populaion_region',
                interactive: true,
                title: '<img src="styles/legend/populaion_region_1.png" /> populaion_region'
            });
var format_DonnestemporellesSIGporttp42025imane_2 = new ol.format.GeoJSON();
var features_DonnestemporellesSIGporttp42025imane_2 = format_DonnestemporellesSIGporttp42025imane_2.readFeatures(json_DonnestemporellesSIGporttp42025imane_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_DonnestemporellesSIGporttp42025imane_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_DonnestemporellesSIGporttp42025imane_2.addFeatures(features_DonnestemporellesSIGporttp42025imane_2);
cluster_DonnestemporellesSIGporttp42025imane_2 = new ol.source.Cluster({
  distance: 30,
  source: jsonSource_DonnestemporellesSIGporttp42025imane_2
});
var lyr_DonnestemporellesSIGporttp42025imane_2 = new ol.layer.Vector({
                declutter: false,
                source:cluster_DonnestemporellesSIGporttp42025imane_2, 
                style: style_DonnestemporellesSIGporttp42025imane_2,
                popuplayertitle: 'Données temporelles SIG port tp 4 2025 imane',
                interactive: true,
                title: '<img src="styles/legend/DonnestemporellesSIGporttp42025imane_2.png" /> Données temporelles SIG port tp 4 2025 imane'
            });

lyr_GoogleHybrid_0.setVisible(true);lyr_populaion_region_1.setVisible(true);lyr_DonnestemporellesSIGporttp42025imane_2.setVisible(true);
var layersList = [lyr_GoogleHybrid_0,lyr_populaion_region_1,lyr_DonnestemporellesSIGporttp42025imane_2];
lyr_populaion_region_1.set('fieldAliases', {'CODE_REGIO': 'CODE_REGIO', 'nom_region': 'nom_region', ' Marocains': ' Marocains', 'Etrangers': 'Etrangers', ' Populatio': ' Populatio', ' Menages': ' Menages', 'nom_arabe': 'nom_arabe', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_2': 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_2', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_3': 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_3', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_4': 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_4', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_5': 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_5', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_6': 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_6', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_7': 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_7', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_8': 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_8', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_9': 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_9', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_10': 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_10', });
lyr_DonnestemporellesSIGporttp42025imane_2.set('fieldAliases', {'field_1': 'field_1', 'field_2': 'field_2', 'field_3': 'field_3', 'field_4': 'field_4', 'field_5': 'field_5', 'field_6': 'field_6', 'field_7': 'field_7', 'field_8': 'field_8', 'field_9': 'field_9', });
lyr_populaion_region_1.set('fieldImages', {'CODE_REGIO': 'TextEdit', 'nom_region': 'TextEdit', ' Marocains': 'TextEdit', 'Etrangers': 'TextEdit', ' Populatio': 'TextEdit', ' Menages': 'TextEdit', 'nom_arabe': 'TextEdit', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_2': 'TextEdit', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_3': 'Range', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_4': 'TextEdit', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_5': 'TextEdit', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_6': 'TextEdit', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_7': 'TextEdit', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_8': 'Range', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_9': 'TextEdit', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_10': 'TextEdit', });
lyr_DonnestemporellesSIGporttp42025imane_2.set('fieldImages', {'field_1': '', 'field_2': '', 'field_3': '', 'field_4': '', 'field_5': '', 'field_6': '', 'field_7': '', 'field_8': '', 'field_9': '', });
lyr_populaion_region_1.set('fieldLabels', {'CODE_REGIO': 'header label - visible with data', 'nom_region': 'header label - visible with data', ' Marocains': 'header label - visible with data', 'Etrangers': 'header label - visible with data', ' Populatio': 'header label - visible with data', ' Menages': 'header label - visible with data', 'nom_arabe': 'header label - visible with data', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_2': 'header label - visible with data', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_3': 'header label - visible with data', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_4': 'inline label - visible with data', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_5': 'header label - visible with data', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_6': 'header label - visible with data', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_7': 'header label - visible with data', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_8': 'header label - visible with data', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_9': 'header label - visible with data', 'Données temporelles SIG port tp 4 2025 imane CORRICTION_field_10': 'header label - visible with data', });
lyr_DonnestemporellesSIGporttp42025imane_2.set('fieldLabels', {'field_1': 'header label - visible with data', 'field_2': 'header label - visible with data', 'field_3': 'header label - visible with data', 'field_4': 'header label - visible with data', 'field_5': 'header label - visible with data', 'field_6': 'header label - visible with data', 'field_7': 'header label - visible with data', 'field_8': 'header label - visible with data', 'field_9': 'header label - visible with data', });
lyr_DonnestemporellesSIGporttp42025imane_2.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});